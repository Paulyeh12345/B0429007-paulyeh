
#改編自 dodger.py  http://inventwithpython.com/dodger.py

"""玩家所控制為一台戰機，可以左右移動，一共會有兩個敵人以及一個補包，
他們會往下掉，只要戰機碰到即可觸發，扣分又扣100及扣50，加分為一個加50分，
一共有5關，每關有1000時間，每關至少需要750分才可過關，分數會隨著時間增加，
每過一關敵人飛行速度會增加，碰到敵人會觸發爆炸效果並扣分，相對的，
碰到補包會加分也有加分音效，達到時間5000即第五關，即可獲勝!"""

""" 音效來源:
加分音效http://www.aigei.com/view/20601.html
過關音效http://www.aigei.com/view/20601.html
開始音效https://www.youtube.com/watch?v=fl7MI8ZlczE
失敗音效https://www.youtube.com/watch?v=-bzWSJG93P8
勝利音效https://www.youtube.com/watch?v=BjDaPOWdx6s

圖片來源:
使用者戰績: https://www.google.com/imgres?imgrefurl=https://www.pinterest.com/pin/413064597046561970/&tbnid=1V4ixeZ4wlfStM:&docid=yHNgCRSwkrQvfM&h=354&w=236
敵人戰績1:手繪
敵人戰績2:手繪
加分圖片https://icons8.com/icon/set/plus/all
爆炸圖片ttps://icons8.com/icon/set/boom/all
背景圖片: http://cw1.tw/CW/images/article/C1437792476599.jpg

圖片可能因為檔案路徑更動失效，執行可能須重新載入

"""
#BY B0429007 葉柏諭 2017/06
import pygame, random, sys,time
from pygame.locals import *

#顯示控制
#螢幕寬
WINDOWWIDTH = 1200
#螢幕高
WINDOWHEIGHT = 700
#文字顏色
TEXTCOLOR = (255, 150, 0)
#進入的背景顏色
BACKGROUNDCOLOR = (0, 0, 0)
#幀率
FPS = 200

#遊戲設置
#敵人1的速度、頻率、大小
enemyspeed =7
ADDNEW = 15
enemysize = 25

#敵人2的速度、頻率、大小
enemy2speed =7
ADDNEW2 = 30
enemy2size = 80

#加分的速度、頻率、大小
plusspeed =5
ADDNEWplus = 30
plussize = 25

#玩家移動速度
PLAYERMOVERATE = 15

#離開
def leave():
    pygame.quit()
    sys.exit()

#等待使用者按下按鍵
def PressKey():
    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                leave()
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    leave()
                return

#文字顯示控制
def drawText(text, font, surface, x, y):
    textobj = font.render(text, 1, TEXTCOLOR)
    textrect = textobj.get_rect()
    textrect.topleft = (x, y)
    surface.blit(textobj, textrect)

#load與設置遊戲背景、音效、圖片
pygame.init()
mainClock = pygame.time.Clock()
windowSurface = pygame.display.set_mode((WINDOWWIDTH, WINDOWHEIGHT))

#名稱
pygame.display.set_caption('蹦!蹦!蹦!炸死你全家')
#背景
pygame.image.load("Back.jpg")
background_image = pygame.image.load("back.jpg")
#顯示背景
windowSurface.blit(background_image, [0, 0])
#使滑鼠消失
pygame.mouse.set_visible(False)

# 比例
font = pygame.font.SysFont(None, 50)

#音效
#遊戲結束音效
gameOverSound = pygame.mixer.Sound('lose.wav')
#碰撞炸彈音效
bombSound = pygame.mixer.Sound('enemy.wav')
#過關音效
nextstage = pygame.mixer.Sound('up.wav')
#遊戲勝利音效
win = pygame.mixer.Sound('win.wav')
#獲得加分音效
plusSound = pygame.mixer.Sound('plus.wav')
#遊戲進行音效
pygame.mixer.music.load('Star Wars.mp3')

#圖片
#玩家戰機
playerImage = pygame.image.load('222.png')
playerRect = playerImage.get_rect()
#敵人一
enemyImage = pygame.image.load('enemy.png')
#敵人2
enemy2Image = pygame.image.load('enemy2.png')
#爆炸效果圖片
bombImage = pygame.image.load('boomer.png')
#加分圖片\
plusImage = pygame.image.load('plus.png')
PressKey()

#文字排版
drawText('Final Project', font, windowSurface, (WINDOWWIDTH / 3), (WINDOWHEIGHT / 3)-50)

drawText('S', font, windowSurface, (WINDOWWIDTH / 3), (WINDOWHEIGHT / 3))
pygame.display.update()
time.sleep(0.2)
drawText('i', font, windowSurface, (WINDOWWIDTH / 3)+20, (WINDOWHEIGHT / 3))
pygame.display.update()
time.sleep(0.2)
drawText('g', font, windowSurface, (WINDOWWIDTH / 3)+30, (WINDOWHEIGHT / 3))
pygame.display.update()
time.sleep(0.2)
drawText('n', font, windowSurface, (WINDOWWIDTH / 3)+50 , (WINDOWHEIGHT / 3))
pygame.display.update()
time.sleep(0.2)
drawText('a', font, windowSurface, (WINDOWWIDTH / 3)+70 , (WINDOWHEIGHT / 3))
pygame.display.update()
time.sleep(0.2)
drawText('l', font, windowSurface, (WINDOWWIDTH / 3)+90 , (WINDOWHEIGHT / 3))
pygame.display.update()
time.sleep(0.2)
drawText('s', font, windowSurface, (WINDOWWIDTH / 3)+100 , (WINDOWHEIGHT / 3))
pygame.display.update()
time.sleep(0.2)
drawText('and', font, windowSurface, (WINDOWWIDTH / 3)+150 , (WINDOWHEIGHT / 3))
pygame.display.update()
time.sleep(0.2)
drawText('S', font, windowSurface, (WINDOWWIDTH / 3)+240 , (WINDOWHEIGHT / 3))
pygame.display.update()
time.sleep(0.2)
drawText('y', font, windowSurface, (WINDOWWIDTH / 3)+260 , (WINDOWHEIGHT / 3))
pygame.display.update()
time.sleep(0.2)
drawText('s', font, windowSurface, (WINDOWWIDTH / 3)+280 , (WINDOWHEIGHT / 3))
pygame.display.update()
time.sleep(0.2)
drawText('t', font, windowSurface, (WINDOWWIDTH / 3)+300 , (WINDOWHEIGHT / 3))
pygame.display.update()
time.sleep(0.2)
drawText('e', font, windowSurface, (WINDOWWIDTH / 3)+310 , (WINDOWHEIGHT / 3))
pygame.display.update()
time.sleep(0.2)
drawText('m', font, windowSurface, (WINDOWWIDTH / 3)+330 , (WINDOWHEIGHT / 3))
pygame.display.update()
time.sleep(0.2)
drawText('s', font, windowSurface, (WINDOWWIDTH / 3)+360 , (WINDOWHEIGHT / 3))
pygame.display.update()
time.sleep(1)
drawText('Ready', font, windowSurface, (WINDOWWIDTH / 3) , (WINDOWHEIGHT / 3)+50)
pygame.display.update()
time.sleep(1)
drawText('GO!', font, windowSurface, (WINDOWWIDTH / 3)+140 , (WINDOWHEIGHT / 3)+50)
pygame.display.update()
time.sleep(1)

topscore=0
#遊戲開始
while True:
    plus = []
    enemys = []
    enemy2=[]

    #初始設定
    score = 0
    time=0

#初始玩家位置
    playerRect.topleft = (WINDOWWIDTH / 2, WINDOWHEIGHT - 150)
    moveLeft = moveRight =False
    reverseCheat = slowCheat = fastCheat = False

    enemyAddCounter = 0
    enemy2AddCounter = 0
    plusAddCounter = 0
    pygame.mixer.music.play(-1, 0.0)

    while True:
        score += 1 # increase score
        time +=1

        #玩家移動設置
        for event in pygame.event.get():
            if event.type == QUIT:
                leave()

            if event.type == KEYDOWN:
                #減速
                if event.key == ord('z'):
                    reverseCheat = True
                #倒退
                if event.key == ord('x'):
                    slowCheat = True
                #加速
                if event.key ==ord('c'):
                    fastCheat =True
                #向左
                if event.key == K_LEFT or event.key == ord('a'):
                    moveRight = False
                    moveLeft = True
                #向右
                if event.key == K_RIGHT or event.key == ord('d'):
                    moveLeft = False
                    moveRight = True
                    #控制加速、減速、倒退
            if event.type == KEYUP:
                if event.key == ord('z'):
                    reverseCheat = False
                if event.key == ord('x'):
                    slowCheat = False
                if event.key == ord('c'):
                    fastCheat = False
                    #離開
                if event.key == K_ESCAPE:
                        leave()

                if event.key == K_LEFT or event.key == ord('a'):
                    moveLeft = False
                if event.key == K_RIGHT or event.key == ord('d'):
                    moveRight = False

        # 增加敵人與加分
        if not reverseCheat and not slowCheat :
            enemyAddCounter += 1
            enemy2AddCounter += 1
            plusAddCounter += 1

            #敵人1
        if enemyAddCounter == ADDNEW:
            enemyAddCounter = 0

            #出現位置、速度，圖片大小
            newenemy = {'rect': pygame.Rect(random.randint(0, WINDOWWIDTH-enemysize), 0 - enemysize, enemysize, enemysize),
                        'speed': enemyspeed,
                        'surface':pygame.transform.scale(enemyImage, (enemysize, enemysize+30)),
                        }
            enemys.append(newenemy)

            #敵人2
        if enemy2AddCounter == ADDNEW2:
            enemy2AddCounter = 0

            #出現位置、速度，圖片大小
            newenemy2 = {'rect': pygame.Rect(random.randint(0, WINDOWWIDTH-enemy2size), 0 - enemy2size, enemy2size, enemy2size),
                        'speed': enemy2speed,
                        'surface':pygame.transform.scale(enemy2Image, (enemy2size, enemy2size)),
                        }
            enemy2.append(newenemy2)

            #加分
        if plusAddCounter ==ADDNEWplus:
            plusAddCounter = 0

            #出現位置、速度，圖片大小
            newplus = {'rect': pygame.Rect(random.randint(0, WINDOWWIDTH-plussize), 0 - plussize, plussize, plussize),
                        'speed': plusspeed,
                        'surface':pygame.transform.scale(plusImage, (plussize, plussize)),
                        }
            plus.append(newplus)

        # 讓使用者移動
        if moveLeft and playerRect.left > 0:
            playerRect.move_ip(-1 * PLAYERMOVERATE, 0)


        if moveRight and playerRect.right < WINDOWWIDTH:
            playerRect.move_ip(PLAYERMOVERATE, 0)


        # 敵人1往下
        for b in enemys:
            if not reverseCheat and not slowCheat and not fastCheat:
                b['rect'].move_ip(0, b['speed'])
                #倒退
            elif reverseCheat:
                b['rect'].move_ip(0, -5)
                #減速
            elif slowCheat:
                b['rect'].move_ip(0, 1)
                #加速
            elif fastCheat:
                b['rect'].move_ip(0, b['speed']+5)

        # 到底部時刪除
        for b in enemys[:]:
            if b['rect'].top > WINDOWHEIGHT:
                enemys.remove(b)

        # 敵人2往下
        for e in enemy2:
            if not reverseCheat and not slowCheat and not fastCheat:
                e['rect'].move_ip(0, e['speed'])
                #倒退
            elif reverseCheat:
                e['rect'].move_ip(0, -5)
                #減速
            elif slowCheat:
                e['rect'].move_ip(0, 1)
                #加速
            elif fastCheat:
                e['rect'].move_ip(0, e['speed']+5)

        # 到底部時刪除
        for e in enemy2[:]:
            if e['rect'].top > WINDOWHEIGHT:
                enemy2.remove(e)

        # 加分往下
        for p in plus:
            if not reverseCheat and not slowCheat and not fastCheat:
                p['rect'].move_ip(0, p['speed'])
                #倒退
            elif reverseCheat:
                p['rect'].move_ip(0, -5)
                #減速
            elif slowCheat:
                p['rect'].move_ip(0, 1)
                #加速
            elif fastCheat:
                p['rect'].move_ip(0, p['speed']+5)

        # 到底部時刪除
        for p in plus[:]:
            if p['rect'].top > WINDOWHEIGHT:
                plus.remove(p)

        # 背景刷新
        windowSurface.blit(background_image, [0, 0])

        #分數設置
        if score<0:
             score=0

             #關卡加速

        if time==1000 and score>750 or time==2000 and score>1500 or time ==3000 and score>2250 or time==4000 and score>3000 :
            enemyspeed +=3.2
            enemy2speed +=1.5

            #失敗關卡

        if time==1000 and score<750 or time==2000 and score<1500 or time ==3000 and score<2250 or time==4000 and score<3000 or time==5000 and score<3750:
            if score > topscore:
                topscore = score

            pygame.mixer.music.stop()
            #播放失敗音樂
            gameOverSound.play()
            drawText('you failed', font, windowSurface, (WINDOWWIDTH / 3)-80, (WINDOWHEIGHT / 3))
            drawText('your score: %s' % (score), font, windowSurface
            , (WINDOWWIDTH / 3) - 80, (WINDOWHEIGHT / 3) + 50)
            drawText('TopScore: %s' % (topscore), font, windowSurface
            , (WINDOWWIDTH / 3) -80, (WINDOWHEIGHT / 3) + 100)
            drawText('Press a key to play again.', font, windowSurface
            , (WINDOWWIDTH / 3) - 80, (WINDOWHEIGHT / 3) + 150)
            pygame.display.update()
            pygame.time.wait(3000)
            pygame.display.update()
            mainClock.tick(FPS)
            #等使用者按下案件
            PressKey()
            #停止音樂
            gameOverSound.stop()
            #重設速度避免初始速度跑掉
            enemyspeed =7
            enemy2speed =7
            break

            #勝利關卡

        if time==5000 and score>3750:
            if score > topscore:
                topscore = score

            pygame.mixer.music.stop()
            mainClock.tick(FPS)
            #播放勝利音樂
            win.play()
            drawText('you win!!!', font, windowSurface, (WINDOWWIDTH / 3)-80, (WINDOWHEIGHT / 3))
            drawText('your score: %s' % (score), font, windowSurface, (WINDOWWIDTH / 3) - 80, (WINDOWHEIGHT / 3) + 50)
            drawText('TopScore: %s' % (topscore), font, windowSurface, (WINDOWWIDTH / 3) -80, (WINDOWHEIGHT / 3) + 100)
            drawText('Press a key to play again.', font, windowSurface, (WINDOWWIDTH / 3) - 80, (WINDOWHEIGHT / 3) + 150)
            pygame.display.update()
            pygame.time.wait(3000)
            pygame.display.update()
            #等使用者按下案件
            PressKey()
            #停止音樂
            win.stop()
            #重設速度避免初始速度跑掉
            enemyspeed =7
            enemy2speed =7
            break

            #關卡分數顯示

        drawText('time: %s' % (time), font, windowSurface, 10, 0)
        drawText('score: %s' % (score), font, windowSurface, 10, 40)

        #過關分數控制

        if time<1000:
            drawText('passing score: %s'%(750),font,windowSurface,10,80)

        if time<2000 and time>1000:
            drawText('passing score: %s'%(1500),font,windowSurface,10,80)

            if time==1010:
                nextstage.play()
        if time<3000 and time>2000:
            drawText('passing score: %s'%(2250),font,windowSurface,10,80)

            if time==2010:
                nextstage.play()
        if time<4000 and time>3000:
            drawText('passing score: %s'%(3000),font,windowSurface,10,80)

            if time==3010:
                nextstage.play()
        if time<5000 and time>4000:
            drawText('passing score: %s'%(3750),font,windowSurface,10,80)

            if time==4010:
                nextstage.play()
        # Draw the player's rectangle

        windowSurface.blit(playerImage, playerRect)

        # Draw each enemy
        for b in enemys:
            windowSurface.blit(b['surface'], b['rect'])
        pygame.display.update()

        # 檢查碰撞

        for b in enemys[:]:
             for b in enemys:
                if playerRect.colliderect(b['rect']):

                    #碰到後扣分
                    score=score-50
                    enemys.remove(b)
                    pygame.display.update()
                    #將原圖換成爆炸圖片
                    windowSurface.blit(bombImage, b['rect'])
                    pygame.display.update()
                    #爆炸音效
                    bombSound.play()

        for e in enemy2:
            windowSurface.blit(e['surface'], e['rect'])
        pygame.display.update()

        # 檢查碰撞

        for e in enemy2[:]:
             for e in enemy2:
                if playerRect.colliderect(e['rect']):

                    #碰到後扣分
                    score=score-100
                    enemy2.remove(e)
                    pygame.display.update()
                    #將原圖換成爆炸圖片
                    windowSurface.blit(bombImage, e['rect'])
                    pygame.display.update()
                    #爆炸音效
                    bombSound.play()

        for p in plus:
            windowSurface.blit(p['surface'], p['rect'])
        pygame.display.update()

        # 檢查碰撞

        for p in plus[:]:
             for p in plus:
                if playerRect.colliderect(p['rect']):

                    #碰到後加分
                    score=score+50
                    plus.remove(p)
                    pygame.display.update()
                    #加分音效
                    plusSound.play()

        mainClock.tick(FPS)
